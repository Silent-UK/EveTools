import test from 'node:test';
import assert from 'node:assert/strict';
import {industryPreferences,industryRows,industrySummary,industryProgress,industryCSV,industrySlotLimits,industrySlotSummary} from '../public/industry-dashboard-model.mjs';
import {industryDashboardView} from '../public/industry-dashboard-view.mjs';
const now=Date.parse('2026-11-04T12:00:00Z'),iso=n=>new Date(now+n).toISOString(),job=(id,status,offset)=>({job_id:id,name:'Rifter',activity_id:1,runs:3,status,start_date:iso(-3600000),end_date:iso(offset),location:'Jita'}),pilots=[{id:1,name:'Main',updated:now,data:{jobs:[job(1,'active',3600000),job(2,'active',-1000),job(3,'paused',-1000),job(4,'ready',-1000),job(5,'delivered',-1000)]}},{id:2,name:'Alt',updated:now,data:{jobs:[job(6,'active',172800000)]}}];
test('Industry separates estimated readiness, paused and future jobs without importing delivered history',()=>{const rows=industryRows(pilots,undefined,now),s=industrySummary(rows);assert.equal(rows.length,5);assert.deepEqual([s.running,s.ready,s.soon,s.paused],[2,2,1,1]);assert.ok(rows[0].state.startsWith('ready'));assert.equal(s.next.job_id,1);assert.equal(rows.find(j=>j.job_id===3).state,'paused');});
test('Industry filters combine pilot text, activity, location and finishing window',()=>{assert.equal(industryRows(pilots,industryPreferences({status:'soon'}),now).length,1);assert.equal(industryRows(pilots,industryPreferences({q:'alt'}),now)[0].job_id,6);assert.equal(industryRows(pilots,industryPreferences({activity:'5'}),now).length,0);assert.equal(industryRows(pilots,industryPreferences({location:'Amarr'}),now).length,0);assert.equal(industryRows(pilots,industryPreferences({status:'ready'}),now).length,2);});
test('Industry unknown dates and paused jobs never invent progress or ready estimates',()=>{assert.equal(industryProgress({...job(1,'active',3600000),start_date:null},now),null);assert.equal(industryProgress(job(1,'paused',3600000),now),null);assert.equal(industryProgress(job(1,'active',3600000),now),50);const rows=industryRows([{id:1,name:'Main',data:{jobs:[{...job(1,'active',0),end_date:'bad'}]}}],undefined,now);assert.equal(rows[0].state,'active');assert.equal(rows[0].soon,false);});
test('Industry CSV exports all matches with safe cells and snapshot provenance',()=>{const rows=industryRows([{...pilots[0],name:'=HYPERLINK("evil")'}],undefined,now),csv=industryCSV(rows);assert.ok(csv.includes('Snapshot UTC'));assert.ok(csv.includes("'"+'=HYPERLINK'));assert.equal(csv.split('\r\n').length,5);assert.ok(csv.includes('ready-estimated'));});
test('Industry suppresses duplicate job IDs per pilot without collapsing different pilots',()=>{const p={...pilots[0],data:{jobs:[job(1,'active',3600000),job(1,'active',3600000)]}};assert.equal(industryRows([p,{...p,id:2}],undefined,now).length,2);});
test('Industry view escapes data, handles unavailable coverage and paginates the table only',()=>{const list=[{id:1,name:'<script>bad</script>',error:'<error>',data:{jobs:Array.from({length:105},(_,i)=>({...job(i,'active',3600000),name:'<unsafe>'}))}}],html=industryDashboardView(list,industryPreferences(),0,now);assert.ok(!html.includes('<script>'));assert.ok(html.includes('&lt;unsafe&gt;'));assert.ok(html.includes('1–100 of 105'));assert.equal((html.match(/<tr class=/g)||[]).length,100);assert.equal(industryRows(list,undefined,now).length,105);assert.ok(html.includes('saved snapshot retained'));});
test('Industry preferences reject unsupported values and grouped view keeps character labels',()=>{assert.equal(industryPreferences({status:'delivered',activity:'invalid',sort:'bad'}).status,'');const html=industryDashboardView(pilots,industryPreferences({grouped:true}),0,now);assert.ok(html.includes('Main · 4 jobs'));assert.ok(html.includes('Alt · 1 jobs'));assert.ok(html.includes('industry-stripe-1'));});

test('Industry supports both reaction activities and renders numeric snapshot dates',()=>{const list=[{id:1,name:'Pilot',updated:now,data:{jobs:[{...job(1,'active',3600000),activity_id:9},{...job(2,'active',3600000),activity_id:11}]}}];assert.equal(industryRows(list,industryPreferences({activity:'reaction'}),now).length,2);const html=industryDashboardView(list,industryPreferences(),0,now);assert.ok(html.includes('04/11/2026'));assert.ok(!html.includes('Latest successful refresh: Unavailable'));});

test('Industry slots count active skill levels and all outstanding jobs across pilots',()=>{
 const slot_limits=industrySlotLimits([
  {skill_id:3387,active_skill_level:5},
  {skill_id:24625,active_skill_level:0,trained_skill_level:5},
  {skill_id:45748,active_skill_level:2},
  {skill_id:3406,active_skill_level:3},
 ]);
 assert.deepEqual(slot_limits,{manufacturing:6,reactions:3,science:4});
 const main={...pilots[0],slot_limits,data:{jobs:[
  ...pilots[0].data.jobs,
  {...job(7,'active',1000),activity_id:9},
  {...job(8,'paused',1000),activity_id:11},
  {...job(9,'ready',-1000),activity_id:5},
 ]}};
 const alt={...pilots[1],slot_limits:industrySlotLimits([])};
 const list=[main,alt,{id:3,name:'No Industry snapshot',slot_limits}];
 const totals=industrySlotSummary(list,industryRows(list,undefined,now));
 assert.deepEqual(totals.map(({used,total,free,covered})=>[used,total,free,covered]),[[5,7,2,2],[2,4,2,2],[1,5,4,2]]);
 const html=industryDashboardView([main],industryPreferences({status:'paused'}),0,now);
 assert.match(html,/Manufacturing Slots<\/small><strong>4\/6<\/strong><small>2 free/);
 assert.match(industryDashboardView(list,industryPreferences(),0,now),/2\/3 pilots/);
 assert.match(industryDashboardView([list[2]],industryPreferences(),0,now),/Free slots unavailable/);
 assert.equal(industrySlotLimits(null),null);
});
